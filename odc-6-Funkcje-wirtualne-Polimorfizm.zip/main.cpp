#include <iostream>
using namespace std;

class ksztalt
{
  public:
  virtual void oblicz()=0;
  // czysta funckja wirtualna
};

class kolo :public ksztalt
{
  float r;
  public:
  //methods
  kolo(float x)
  {
    r=x;
  }
  virtual void oblicz()
  {
    cout<<"Pole kola: "<<3.14*r*r<<endl;
  }
};

class kwadrat :public ksztalt
{
  float a;
  public:
  kwadrat(float x)
  {
    a=x;
  }
  virtual void oblicz()
  {
    cout<<"Pole kwadratu: "<<a*a<<endl;
  }
};

//----------------------------------------------//

void obliczenia(ksztalt *x)
{
  x->oblicz();
}
 
//----------------------------------------------//

int main() 
{
  float y;
  cout<<"podaj r kola: "<<endl; cin>>y;
  kolo k(y);
  cout<<"podaj a kwadratu: "<<endl; cin>>y;
  kwadrat kw(y);
  ksztalt *wsk;

  wsk = &k;
  wsk ->oblicz();

  wsk = &kw;
  wsk ->oblicz();

obliczenia(wsk);

}